<?php
namespace Models;

class StoreProductModel extends Model
{
    protected string $table = 'store_products';

    public function __construct(?\PDO $db = null)
    {
        parent::__construct($db);
        $this->ensureSchema();
    }

    public function createMany(array $items, int $staffId): array
    {
        $created = 0;
        foreach ($items as $item) {
            $name = trim((string) ($item['name'] ?? ''));
            $hasAnyData = $name !== ''
                || (float) ($item['quantity'] ?? 0) > 0
                || (float) ($item['package_quantity'] ?? 0) > 0
                || (float) ($item['buying_price'] ?? 0) > 0
                || (float) ($item['package_buying_price'] ?? 0) > 0
                || (float) ($item['retail_price'] ?? 0) > 0
                || (float) ($item['wholesale_price'] ?? 0) > 0
                || (float) ($item['package_price'] ?? 0) > 0
                || (float) ($item['retail_pack_price'] ?? 0) > 0
                || trim((string) ($item['barcode'] ?? '')) !== '';
            if (!$hasAnyData) {
                continue;
            }

            if ($name === '') {
                $p = (float) ($item['retail_price'] ?? $item['package_price'] ?? $item['retail_pack_price'] ?? $item['buying_price'] ?? $item['package_buying_price'] ?? 0);
                $name = $p > 0 ? ('Product KES ' . number_format($p, 0)) : ('Item ' . date('j M H:i'));
            }

            $inside = ($item['units_per_package'] ?? '') !== '' ? max(0.01, (float) $item['units_per_package']) : 1.0;
            $pkgQty = ($item['package_quantity'] ?? '') !== '' ? max(0, (float) $item['package_quantity']) : null;
            $qty = (float) ($item['quantity'] ?? 0);
            if ($qty <= 0 && $pkgQty !== null && $pkgQty > 0) {
                $qty = round($pkgQty * $inside, 2);
            }
            $unit = $item['unit'] ?? 'piece';
            $pkgUnit = trim((string) ($item['package_unit'] ?? ''));
            if ($pkgUnit === '') {
                // Continuous goods (kg/L) can sit as loose measured stock without a carton default.
                $pkgUnit = ProductModel::isContinuousUnit($unit) ? null : 'carton';
            }

            $this->insert([
                'product_id' => (int) ($item['product_id'] ?? 0) ?: null,
                'name' => $name,
                'category_id' => (int) ($item['category_id'] ?? 0) ?: null,
                'brand_id' => (int) ($item['brand_id'] ?? 0) ?: null,
                'supplier_id' => (int) ($item['supplier_id'] ?? 0) ?: null,
                'barcode' => trim((string) ($item['barcode'] ?? '')) ?: null,
                'unit' => $unit,
                'package_unit' => $pkgUnit,
                'package_quantity' => $pkgQty,
                'units_per_package' => $inside,
                'package_price' => ($item['package_price'] ?? '') !== '' ? max(0, (float) $item['package_price']) : null,
                'retail_pack_price' => ($item['retail_pack_price'] ?? '') !== '' ? max(0, (float) $item['retail_pack_price']) : null,
                'colors' => trim((string) ($item['colors'] ?? '')) ?: null,
                'quantity' => $qty,
                'faulty_quantity' => max(0, (float) ($item['faulty_quantity'] ?? 0)),
                'buying_price' => max(0, (float) ($item['buying_price'] ?? 0)),
                'package_buying_price' => ($item['package_buying_price'] ?? '') !== '' ? max(0, (float) $item['package_buying_price']) : null,
                'retail_price' => max(0, (float) ($item['retail_price'] ?? 0)),
                'wholesale_price' => max(0, (float) ($item['wholesale_price'] ?? 0)),
                'offer_price' => ($item['offer_price'] ?? '') !== '' ? max(0, (float) $item['offer_price']) : null,
                'offer_starts_at' => $this->dateOrNull($item['offer_starts_at'] ?? null),
                'offer_ends_at' => $this->dateOrNull($item['offer_ends_at'] ?? null),
                'image_path' => trim((string) ($item['image_path'] ?? '')) ?: null,
                'notes' => trim((string) ($item['notes'] ?? '')) ?: null,
                'created_by' => $staffId,
                'status' => 'stored',
            ]);
            $created++;
        }
        return ['ok' => $created > 0, 'created' => $created, 'error' => $created > 0 ? null : 'Add at least one stored product.'];
    }

    public function pending(): array
    {
        $tid = \TenantContext::tenantId();
        $stmt = $this->db->prepare(
            "SELECT sp.*, c.name AS category_name, br.name AS brand_name, s.name AS supplier_name
               FROM store_products sp
          LEFT JOIN categories c ON c.id = sp.category_id
          LEFT JOIN book_attributes br ON br.id = sp.brand_id
          LEFT JOIN suppliers s ON s.id = sp.supplier_id
              WHERE sp.tenant_id = ? AND sp.status = 'stored'
           ORDER BY sp.created_at DESC, sp.id DESC"
        );
        $stmt->execute([$tid]);
        return $stmt->fetchAll();
    }

    public function invoices(int $limit = 100, ?string $type = null): array
    {
        $tid = \TenantContext::tenantId();
        $typeSql = $type ? (" AND si.invoice_type = " . $this->db->quote($type)) : "";
        $stmt = $this->db->prepare(
            "SELECT si.*, u.username AS created_by_name,
                    (SELECT COUNT(*) FROM store_invoice_items sii WHERE sii.invoice_id = si.id) AS item_count
               FROM store_invoices si
          LEFT JOIN users u ON u.id = si.created_by
              WHERE si.tenant_id = ? {$typeSql}
           ORDER BY si.created_at DESC, si.id DESC
              LIMIT " . (int) $limit
        );
        $stmt->execute([$tid]);
        return $this->withProductSummary($stmt->fetchAll());
    }

    public function returnInvoices(int $limit = 100): array
    {
        return $this->invoices($limit, 'return');
    }

    /** Warehouse capital still in Store + shop Inventory capital (buying cost). */
    public function capitalSummary(): array
    {
        $tid = \TenantContext::tenantId();
        $warehouse = ['qty' => 0.0, 'capital' => 0.0, 'lines' => 0];
        $shop = ['qty' => 0.0, 'capital' => 0.0, 'lines' => 0];
        try {
            $st = $this->db->prepare(
                "SELECT COUNT(*) AS `lines`,
                        COALESCE(SUM(quantity),0) AS qty,
                        COALESCE(SUM(quantity * COALESCE(buying_price,0)),0) AS capital
                   FROM store_products
                  WHERE tenant_id = ? AND status = 'stored'"
            );
            $st->execute([$tid]);
            $row = $st->fetch() ?: [];
            $warehouse = [
                'qty' => round((float) ($row['qty'] ?? 0), 2),
                'capital' => round((float) ($row['capital'] ?? 0), 2),
                'lines' => (int) ($row['lines'] ?? 0),
            ];
        } catch (\Throwable $ignored) {
        }
        try {
            $st = $this->db->prepare(
                "SELECT COUNT(*) AS `lines`,
                        COALESCE(SUM(quantity),0) AS qty,
                        COALESCE(SUM(quantity * COALESCE(buying_price,0)),0) AS capital
                   FROM products
                  WHERE tenant_id = ? AND status IN ('active','draft')"
            );
            $st->execute([$tid]);
            $row = $st->fetch() ?: [];
            $shop = [
                'qty' => round((float) ($row['qty'] ?? 0), 2),
                'capital' => round((float) ($row['capital'] ?? 0), 2),
                'lines' => (int) ($row['lines'] ?? 0),
            ];
        } catch (\Throwable $ignored) {
        }
        return [
            'warehouse' => $warehouse,
            'shop' => $shop,
            'total_capital' => round($warehouse['capital'] + $shop['capital'], 2),
        ];
    }

    /** Internal transfer invoices in a period (Store → Inventory). */
    public function transfersForPeriod(string $period = 'all', int $limit = 100): array
    {
        $tid = \TenantContext::tenantId();
        $where = $this->periodSql($period, 'si.created_at');
        $stmt = $this->db->prepare(
            "SELECT si.*, u.username AS created_by_name,
                    (SELECT COUNT(*) FROM store_invoice_items sii WHERE sii.invoice_id = si.id) AS item_count
               FROM store_invoices si
          LEFT JOIN users u ON u.id = si.created_by
              WHERE si.tenant_id = ? AND {$where}
           ORDER BY si.created_at DESC, si.id DESC
              LIMIT " . (int) $limit
        );
        $stmt->execute([$tid]);
        return $this->withProductSummary($stmt->fetchAll());
    }

    public function transferTotalForPeriod(string $period = 'all'): float
    {
        $tid = \TenantContext::tenantId();
        $where = $this->periodSql($period, 'created_at');
        $stmt = $this->db->prepare(
            "SELECT COALESCE(SUM(total),0) FROM store_invoices WHERE tenant_id = ? AND {$where}"
        );
        $stmt->execute([$tid]);
        return round((float) $stmt->fetchColumn(), 2);
    }

    private function periodSql(string $period, string $col): string
    {
        if ($period === 'today') {
            return "DATE({$col}) = CURDATE()";
        }
        if ($period === 'week') {
            return "{$col} >= '" . date('Y-m-d', strtotime('-7 days')) . "'";
        }
        if ($period === 'month') {
            return "{$col} >= '" . date('Y-m-d', strtotime('-30 days')) . "'";
        }
        return '1=1';
    }

    public function invoice(int $id): ?array
    {
        $tid = \TenantContext::tenantId();
        $stmt = $this->db->prepare(
            "SELECT si.*, u.username AS created_by_name
               FROM store_invoices si
          LEFT JOIN users u ON u.id = si.created_by
              WHERE si.id = ? AND si.tenant_id = ? LIMIT 1"
        );
        $stmt->execute([$id, $tid]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function invoiceItems(int $invoiceId): array
    {
        $tid = \TenantContext::tenantId();
        $stmt = $this->db->prepare('SELECT * FROM store_invoice_items WHERE invoice_id = ? AND tenant_id = ? ORDER BY id ASC');
        $stmt->execute([$invoiceId, $tid]);
        return $stmt->fetchAll();
    }

    public function updatePending(int $id, array $item): array
    {
        $tid = \TenantContext::tenantId();
        $name = trim((string) ($item['name'] ?? ''));
        $qty = (float) ($item['quantity'] ?? 0);
        if ($name === '' || $qty <= 0) {
            return ['ok' => false, 'error' => 'Enter product name and quantity.'];
        }
        $stmt = $this->db->prepare("SELECT id FROM store_products WHERE id = ? AND tenant_id = ? AND status = 'stored' LIMIT 1");
        $stmt->execute([$id, $tid]);
        if (!$stmt->fetch()) {
            return ['ok' => false, 'error' => 'Stored product not found or already transferred.'];
        }
        $this->db->prepare(
            'UPDATE store_products
                SET name = ?, category_id = ?, brand_id = ?, supplier_id = ?, barcode = ?, unit = ?, colors = ?,
                    quantity = ?, faulty_quantity = ?, buying_price = ?, package_buying_price = ?, retail_price = ?, wholesale_price = ?,
                    package_unit = ?, package_quantity = ?, units_per_package = ?, package_price = ?, retail_pack_price = ?, notes = ?
              WHERE id = ? AND tenant_id = ? AND status = \'stored\''
        )->execute([
            $name,
            (int) ($item['category_id'] ?? 0) ?: null,
            (int) ($item['brand_id'] ?? 0) ?: null,
            (int) ($item['supplier_id'] ?? 0) ?: null,
            trim((string) ($item['barcode'] ?? '')) ?: null,
            $item['unit'] ?? 'piece',
            trim((string) ($item['colors'] ?? '')) ?: null,
            $qty,
            max(0, (float) ($item['faulty_quantity'] ?? 0)),
            max(0, (float) ($item['buying_price'] ?? 0)),
            ($item['package_buying_price'] ?? '') !== '' ? max(0, (float) $item['package_buying_price']) : null,
            max(0, (float) ($item['retail_price'] ?? 0)),
            max(0, (float) ($item['wholesale_price'] ?? 0)),
            trim((string) ($item['package_unit'] ?? '')) ?: null,
            ($item['package_quantity'] ?? '') !== '' ? max(0, (float) $item['package_quantity']) : null,
            ($item['units_per_package'] ?? '') !== '' ? max(0.01, (float) $item['units_per_package']) : null,
            ($item['package_price'] ?? '') !== '' ? max(0, (float) $item['package_price']) : null,
            ($item['retail_pack_price'] ?? '') !== '' ? max(0, (float) $item['retail_pack_price']) : null,
            trim((string) ($item['notes'] ?? '')) ?: null,
            $id,
            $tid,
        ]);
        return ['ok' => true, 'error' => null];
    }

    public function deletePending(int $id): array
    {
        $tid = \TenantContext::tenantId();
        $stmt = $this->db->prepare("DELETE FROM store_products WHERE id = ? AND tenant_id = ? AND status = 'stored'");
        $stmt->execute([$id, $tid]);
        return $stmt->rowCount() > 0
            ? ['ok' => true, 'error' => null]
            : ['ok' => false, 'error' => 'Stored product not found or already transferred.'];
    }

    /**
     * Internal transfer Store → Inventory.
     * $packageQuantities[store_product_id] = how many sealed packages (cartons/bales) to move.
     * Never opens a package — only whole packages. Does not default to transferring everything.
     */
    /**
     * @param array $packageQuantities whole packages to move (cartons/bales)
     * @param array $transferQuantities continuous units (kg/L) to move by quantity
     */
    public function generateInvoice(array $ids, string $invoiceTo, string $notes, int $staffId, array $packageQuantities = [], array $transferQuantities = []): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (!$ids) {
            return ['ok' => false, 'invoice_id' => null, 'error' => 'Choose at least one stored product.'];
        }
        $tid = \TenantContext::tenantId();
        $db = $this->db;
        $productModel = new ProductModel($db);
        try {
            $db->beginTransaction();
            $in = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $db->prepare("SELECT * FROM store_products WHERE tenant_id = ? AND status = 'stored' AND id IN ($in) FOR UPDATE");
            $stmt->execute(array_merge([$tid], $ids));
            $items = $stmt->fetchAll();
            if (!$items) {
                $db->rollBack();
                return ['ok' => false, 'invoice_id' => null, 'error' => 'No stored products are available for that invoice.'];
            }

            $subtotal = 0.0;
            $invoiceItems = [];
            foreach ($items as $it) {
                $unitsPerPkg = max(0.01, (float) ($it['units_per_package'] ?? 1));
                $availableItems = (float) $it['quantity'];
                $availablePkgs = !empty($it['package_unit'])
                    ? (float) ($it['package_quantity'] ?? 0)
                    : 0.0;
                if ($availablePkgs <= 0 && $availableItems > 0 && $unitsPerPkg > 0) {
                    $availablePkgs = round($availableItems / $unitsPerPkg, 2);
                }
                $isContinuous = ProductModel::isContinuousUnit($it['unit'] ?? null);
                $sid = (int) $it['id'];

                if ($isContinuous) {
                    // kg / litre etc: transfer by measured quantity (partial sacks OK).
                    $wantedQty = isset($transferQuantities[$sid]) ? max(0, (float) $transferQuantities[$sid]) : 0.0;
                    if ($wantedQty <= 0 && isset($packageQuantities[$sid])) {
                        $wantedQty = round(max(0, (float) $packageQuantities[$sid]) * $unitsPerPkg, 4);
                    }
                    $qty = min($availableItems, $wantedQty);
                    if ($qty <= 0) {
                        continue;
                    }
                    $pkgs = $unitsPerPkg > 0 ? round($qty / $unitsPerPkg, 4) : null;
                    $copy = $it;
                    $copy['quantity'] = $qty;
                    $copy['transfer_packages'] = $pkgs;
                    $copy['package_quantity'] = $pkgs;
                    $copy['faulty_quantity'] = 0;
                    $invoiceItems[] = $copy;
                    $unitBuy = (float) $it['buying_price'];
                    $subtotal += $qty * $unitBuy;
                    continue;
                }

                if ($availablePkgs <= 0) {
                    $db->rollBack();
                    return ['ok' => false, 'invoice_id' => null, 'error' => ($it['name'] ?? 'Product') . ': no sealed packages left to transfer. Transfers are by package only.'];
                }

                $wantedPkgs = isset($packageQuantities[$sid])
                    ? (float) $packageQuantities[$sid]
                    : 0.0;
                // Whole packages only — no opening cartons in the warehouse transfer.
                $wantedPkgs = floor(max(0, $wantedPkgs) + 1e-9);
                $pkgs = min($availablePkgs, $wantedPkgs);
                if ($pkgs <= 0) {
                    continue;
                }
                $qty = round($pkgs * $unitsPerPkg, 2);
                if ($qty > $availableItems + 0.0001) {
                    $qty = $availableItems;
                    $pkgs = round($qty / $unitsPerPkg, 2);
                }
                if ($qty <= 0) {
                    continue;
                }
                $copy = $it;
                $copy['quantity'] = $qty;
                $copy['transfer_packages'] = $pkgs;
                $copy['package_quantity'] = $pkgs;
                // Sealed packages only — do not move opened/faulty units from the warehouse.
                $copy['faulty_quantity'] = 0;
                $invoiceItems[] = $copy;
                $pkgBuy = ($it['package_buying_price'] ?? '') !== '' && (float) $it['package_buying_price'] > 0
                    ? (float) $it['package_buying_price']
                    : ((float) $it['buying_price'] * $unitsPerPkg);
                $subtotal += $pkgs * $pkgBuy;
            }
            if (!$invoiceItems) {
                $db->rollBack();
                return ['ok' => false, 'invoice_id' => null, 'error' => 'Enter how much to transfer (packages or kg/L) for at least one selected product.'];
            }

            $db->prepare('INSERT INTO store_invoices (tenant_id, invoice_number, invoice_to, total, notes, created_by) VALUES (?,?,?,?,?,?)')
               ->execute([$tid, 'PENDING', trim($invoiceTo) ?: 'Shop Inventory', round($subtotal, 2), trim($notes) ?: null, $staffId]);
            $invoiceId = (int) $db->lastInsertId();
            if ($invoiceId <= 0) {
                $db->rollBack();
                return ['ok' => false, 'invoice_id' => null, 'error' => 'Could not save the transfer invoice record.'];
            }
            $number = 'STR-' . str_pad((string) $invoiceId, 6, '0', STR_PAD_LEFT);
            $db->prepare('UPDATE store_invoices SET invoice_number = ? WHERE id = ? AND tenant_id = ?')->execute([$number, $invoiceId, $tid]);

            foreach ($invoiceItems as $it) {
                $productId = $this->transferOneToInventory($productModel, $it);
                if ($productId <= 0) {
                    throw new \RuntimeException('Transfer did not create/update an inventory product for ' . ($it['name'] ?? 'item'));
                }
                $qty = (float) $it['quantity'];
                $unitPrice = (float) $it['buying_price'];
                $unitPackageQty = max(0.01, (float) ($it['units_per_package'] ?? 1));
                $packageQty = (float) ($it['transfer_packages'] ?? $it['package_quantity'] ?? round($qty / $unitPackageQty, 2));
                $lineTotal = round($qty * $unitPrice, 2);
                $db->prepare(
                    'INSERT INTO store_invoice_items
                        (tenant_id, invoice_id, store_product_id, product_id, product_name, quantity, unit, package_unit, package_quantity, units_per_package, package_price, unit_price, line_total)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
                )->execute([
                    $tid, $invoiceId, (int) $it['id'], $productId, $it['name'], $qty, $it['unit'],
                    $it['package_unit'] ?? null, $packageQty, ($it['units_per_package'] ?? null), ($it['package_price'] ?? null),
                    $unitPrice, $lineTotal,
                ]);
                $originalQty = 0.0;
                $originalPkgs = 0.0;
                foreach ($items as $raw) {
                    if ((int) $raw['id'] === (int) $it['id']) {
                        $originalQty = (float) $raw['quantity'];
                        $units = max(0.01, (float) ($raw['units_per_package'] ?? 1));
                        $originalPkgs = (float) ($raw['package_quantity'] ?? 0);
                        if ($originalPkgs <= 0 && $originalQty > 0) {
                            $originalPkgs = round($originalQty / $units, 2);
                        }
                        break;
                    }
                }
                $remaining = max(0, round($originalQty - $qty, 2));
                $remainingPackageQty = max(0, round($originalPkgs - $packageQty, 2));
                if ($remaining > 0.0001) {
                    $db->prepare('UPDATE store_products SET quantity = ?, package_quantity = ?, product_id = ? WHERE id = ? AND tenant_id = ?')
                       ->execute([$remaining, $remainingPackageQty, $productId, (int) $it['id'], $tid]);
                } else {
                    $db->prepare("UPDATE store_products SET status = 'transferred', quantity = ?, package_quantity = ?, product_id = ?, transferred_invoice_id = ?, transferred_at = NOW() WHERE id = ? AND tenant_id = ?")
                       ->execute([$qty, $packageQty, $productId, $invoiceId, (int) $it['id'], $tid]);
                }
            }

            // Confirm the invoice row really exists before committing the stock move.
            $check = $db->prepare('SELECT id, invoice_number FROM store_invoices WHERE id = ? AND tenant_id = ? LIMIT 1');
            $check->execute([$invoiceId, $tid]);
            $saved = $check->fetch();
            if (!$saved) {
                throw new \RuntimeException('Transfer invoice was not persisted.');
            }

            $db->commit();
            return [
                'ok' => true,
                'invoice_id' => $invoiceId,
                'invoice_number' => (string) ($saved['invoice_number'] ?: $number),
                'error' => null,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('StoreProductModel::generateInvoice failed: ' . $e->getMessage());
            return ['ok' => false, 'invoice_id' => null, 'error' => 'Could not generate and save the transfer invoice. ' . $e->getMessage()];
        }
    }

    public function deleteInvoice(int $invoiceId): array
    {
        $tid = \TenantContext::tenantId();
        $db = $this->db;
        try {
            $db->beginTransaction();
            $stmt = $db->prepare('SELECT * FROM store_invoices WHERE id = ? AND tenant_id = ? FOR UPDATE');
            $stmt->execute([$invoiceId, $tid]);
            $invoice = $stmt->fetch();
            if (!$invoice) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'Store invoice not found.'];
            }
            $itemsStmt = $db->prepare('SELECT * FROM store_invoice_items WHERE invoice_id = ? AND tenant_id = ? ORDER BY id ASC');
            $itemsStmt->execute([$invoiceId, $tid]);
            $items = $itemsStmt->fetchAll();
            $dec = $db->prepare('UPDATE products SET quantity = quantity - ? WHERE id = ? AND tenant_id = ? AND quantity >= ?');
            foreach ($items as $it) {
                $qty = (float) $it['quantity'];
                if ((int) ($it['product_id'] ?? 0) > 0) {
                    $dec->execute([$qty, (int) $it['product_id'], $tid, $qty]);
                    if ($dec->rowCount() !== 1) {
                        $db->rollBack();
                        return ['ok' => false, 'error' => 'Cannot delete this store invoice because some transferred stock has already been sold.'];
                    }
                }
                $sp = $db->prepare('SELECT id, status FROM store_products WHERE id = ? AND tenant_id = ? FOR UPDATE');
                $sp->execute([(int) $it['store_product_id'], $tid]);
                $stored = $sp->fetch();
                if ($stored) {
                    if (($stored['status'] ?? '') === 'transferred') {
                        $packageQty = !empty($it['package_unit']) && (float) ($it['units_per_package'] ?? 0) > 0
                            ? round($qty / (float) $it['units_per_package'], 2)
                            : null;
                        $db->prepare("UPDATE store_products SET status = 'stored', quantity = ?, package_quantity = ?, transferred_invoice_id = NULL, transferred_at = NULL WHERE id = ? AND tenant_id = ?")
                           ->execute([$qty, $packageQty, (int) $it['store_product_id'], $tid]);
                    } else {
                        $packageQty = !empty($it['package_unit']) && (float) ($it['units_per_package'] ?? 0) > 0
                            ? round($qty / (float) $it['units_per_package'], 2)
                            : 0;
                        $db->prepare('UPDATE store_products SET quantity = quantity + ?, package_quantity = COALESCE(package_quantity, 0) + ? WHERE id = ? AND tenant_id = ?')
                           ->execute([$qty, $packageQty, (int) $it['store_product_id'], $tid]);
                    }
                }
            }
            $db->prepare('DELETE FROM store_invoice_items WHERE invoice_id = ? AND tenant_id = ?')->execute([$invoiceId, $tid]);
            $db->prepare('DELETE FROM store_invoices WHERE id = ? AND tenant_id = ?')->execute([$invoiceId, $tid]);
            $db->commit();
            return ['ok' => true, 'error' => null];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('StoreProductModel::deleteInvoice failed: ' . $e->getMessage());
            return ['ok' => false, 'error' => 'Could not delete the store invoice.'];
        }
    }

    /**
     * Return products from Shop Inventory back to Store Warehouse.
     * Generates a Warehouse Return Note (WRN-xxxxxx).
     * Reduces shop inventory and restores warehouse store products.
     * Tracks profit reduction.
     *
     * @param array $items [ ['product_id' => int, 'quantity' => float, 'package_quantity' => ?float], ... ]
     */
    public function returnToWarehouse(array $items, string $notes, int $staffId): array
    {
        $tid = \TenantContext::tenantId();
        $db = $this->db;
        $items = array_values(array_filter($items, fn($it) => (int)($it['product_id'] ?? 0) > 0 && (float)($it['quantity'] ?? 0) > 0));
        if (!$items) {
            return ['ok' => false, 'invoice_id' => null, 'error' => 'Choose at least one shop product and quantity to return.'];
        }

        try {
            $db->beginTransaction();

            $subtotalCost = 0.0;
            $profitReduced = 0.0;
            $returnItems = [];

            foreach ($items as $item) {
                $pid = (int) $item['product_id'];
                $returnQty = (float) $item['quantity'];

                $sel = $db->prepare('SELECT * FROM products WHERE id = ? AND tenant_id = ? FOR UPDATE');
                $sel->execute([$pid, $tid]);
                $prod = $sel->fetch();
                if (!$prod) {
                    throw new \RuntimeException('Shop product #' . $pid . ' not found.');
                }

                $available = (float) $prod['quantity'];
                if ($returnQty > $available + 0.0001) {
                    throw new \RuntimeException('Cannot return ' . $returnQty . ' of ' . $prod['name'] . '; only ' . $available . ' available in shop.');
                }

                $unitsPerPack = max(0.01, (float) ($prod['units_per_pack'] ?? 1));
                $pkgUnit = trim((string) ($prod['pack_unit'] ?? '')) ?: 'carton';
                $returnPkgs = isset($item['package_quantity']) && (float) $item['package_quantity'] > 0
                    ? (float) $item['package_quantity']
                    : ($unitsPerPack > 1 ? round($returnQty / $unitsPerPack, 2) : $returnQty);

                $unitBuy = (float) ($prod['buying_price'] ?? 0);
                if ($unitBuy <= 0 && (float) ($prod['package_buying_price'] ?? 0) > 0 && $unitsPerPack > 0) {
                    $unitBuy = round((float) $prod['package_buying_price'] / $unitsPerPack, 2);
                }
                $unitRetail = (float) ($prod['retail_price'] ?? $prod['selling_price'] ?? 0);
                $unitProfit = max(0, $unitRetail - $unitBuy);

                $lineCost = round($returnQty * $unitBuy, 2);
                $lineProfitLoss = round($returnQty * $unitProfit, 2);

                $subtotalCost += $lineCost;
                $profitReduced += $lineProfitLoss;

                $returnItems[] = [
                    'product' => $prod,
                    'quantity' => $returnQty,
                    'package_quantity' => $returnPkgs,
                    'package_unit' => $pkgUnit,
                    'units_per_package' => $unitsPerPack,
                    'unit_price' => $unitBuy,
                    'retail_price' => $unitRetail,
                    'line_total' => $lineCost,
                    'profit_impact' => -$lineProfitLoss,
                ];
            }

            // Insert store_invoices header
            $stmt = $db->prepare(
                'INSERT INTO store_invoices (tenant_id, invoice_number, invoice_type, source, destination, invoice_to, total, profit_impact, notes, created_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            );
            $stmt->execute([
                $tid,
                'PENDING',
                'return',
                'Shop Inventory',
                'Store Warehouse',
                'Store Warehouse',
                round($subtotalCost, 2),
                -round($profitReduced, 2),
                trim($notes) ?: 'Returned from Shop to Store',
                $staffId
            ]);
            $invoiceId = (int) $db->lastInsertId();
            $number = 'WRN-' . str_pad((string) $invoiceId, 6, '0', STR_PAD_LEFT);
            $db->prepare('UPDATE store_invoices SET invoice_number = ? WHERE id = ? AND tenant_id = ?')
               ->execute([$number, $invoiceId, $tid]);

            foreach ($returnItems as $ri) {
                $prod = $ri['product'];
                $pid = (int) $prod['id'];
                $returnQty = $ri['quantity'];
                $returnPkgs = $ri['package_quantity'];

                // 1. Decrement shop product
                $newShopQty = max(0, round((float) $prod['quantity'] - $returnQty, 2));
                $db->prepare('UPDATE products SET quantity = ? WHERE id = ? AND tenant_id = ?')
                   ->execute([$newShopQty, $pid, $tid]);

                // 2. Increment or create store product
                $findSp = $db->prepare(
                    "SELECT id, quantity, package_quantity FROM store_products
                      WHERE tenant_id = ? AND product_id = ? AND status = 'stored'
                   ORDER BY id DESC LIMIT 1"
                );
                $findSp->execute([$tid, $pid]);
                $existingSp = $findSp->fetch();
                $storeProductId = 0;

                if ($existingSp) {
                    $storeProductId = (int) $existingSp['id'];
                    $newStoreQty = round((float) $existingSp['quantity'] + $returnQty, 2);
                    $newStorePkgs = round((float) ($existingSp['package_quantity'] ?? 0) + $returnPkgs, 2);
                    $db->prepare('UPDATE store_products SET quantity = ?, package_quantity = ? WHERE id = ? AND tenant_id = ?')
                       ->execute([$newStoreQty, $newStorePkgs, $storeProductId, $tid]);
                } else {
                    $insSp = $db->prepare(
                        "INSERT INTO store_products (
                            tenant_id, product_id, name, category_id, brand_id, supplier_id, barcode, unit,
                            package_unit, package_quantity, units_per_package, package_price, retail_pack_price,
                            quantity, buying_price, package_buying_price, retail_price, wholesale_price,
                            notes, status, created_by
                        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    );
                    $insSp->execute([
                        $tid,
                        $pid,
                        $prod['name'],
                        $prod['category_id'] ?: null,
                        $prod['brand_id'] ?: null,
                        $prod['supplier_id'] ?: null,
                        $prod['barcode'] ?: null,
                        $prod['unit'] ?: 'piece',
                        $ri['package_unit'],
                        $returnPkgs,
                        $ri['units_per_package'],
                        $prod['pack_price'] ?: null,
                        $prod['retail_pack_price'] ?: null,
                        $returnQty,
                        $ri['unit_price'],
                        $prod['package_buying_price'] ?: null,
                        $prod['retail_price'] ?: 0,
                        $prod['wholesale_price'] ?: 0,
                        'Returned from shop (' . $number . ')',
                        'stored',
                        $staffId
                    ]);
                    $storeProductId = (int) $db->lastInsertId();
                }

                // 3. Insert invoice item
                $db->prepare(
                    'INSERT INTO store_invoice_items (
                        tenant_id, invoice_id, store_product_id, product_id, product_name,
                        quantity, unit, package_unit, package_quantity, units_per_package,
                        package_price, unit_price, line_total, profit_impact
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
                )->execute([
                    $tid,
                    $invoiceId,
                    $storeProductId,
                    $pid,
                    $prod['name'],
                    $returnQty,
                    $prod['unit'] ?? 'piece',
                    $ri['package_unit'],
                    $returnPkgs,
                    $ri['units_per_package'],
                    $prod['pack_price'] ?: null,
                    $ri['unit_price'],
                    $ri['line_total'],
                    $ri['profit_impact'],
                ]);
            }

            $db->commit();
            return [
                'ok' => true,
                'invoice_id' => $invoiceId,
                'invoice_number' => $number,
                'total_cost' => round($subtotalCost, 2),
                'profit_reduced' => round($profitReduced, 2),
                'error' => null,
            ];
        } catch (\Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            return ['ok' => false, 'invoice_id' => null, 'error' => $e->getMessage()];
        }
    }

    private function transferOneToInventory(ProductModel $productModel, array $it): int
    {
        $tid = \TenantContext::tenantId();
        $barcode = trim((string) ($it['barcode'] ?? ''));
        $existing = null;
        $storedProductId = (int) ($it['product_id'] ?? 0);
        if ($storedProductId > 0) {
            $existing = $productModel->find($storedProductId);
            if (!$existing || (int) $existing['tenant_id'] !== (int) $tid) {
                $existing = null;
            }
        }
        if ($barcode !== '') {
            $existing = $existing ?: $productModel->findByBarcode($barcode);
        }
        $existing = $existing ?: $this->findExistingInventoryProduct($it);
        if ($existing) {
            $this->restockExistingInventoryProduct($existing, $it);
            $this->applyQuantityDiscountsFromNotes((int) $existing['id'], (string) ($it['notes'] ?? ''));
            return (int) $existing['id'];
        }
        $res = $productModel->create([
            'product_type' => 'product',
            'name' => $it['name'],
            'category_id' => (int) ($it['category_id'] ?? 0),
            'brand_id' => (int) ($it['brand_id'] ?? 0),
            'supplier_id' => (int) ($it['supplier_id'] ?? 0),
            'barcode' => $barcode,
            'unit' => $it['unit'] ?: 'piece',
            'units_per_pack' => max(0.01, (float) ($it['units_per_package'] ?? 1)),
            'pack_unit' => $it['package_unit'] ?? null,
            'pack_price' => ($it['package_price'] ?? '') !== '' ? (float) $it['package_price'] : null,
            'retail_pack_price' => ($it['retail_pack_price'] ?? '') !== '' ? (float) $it['retail_pack_price'] : null,
            'colors' => $it['colors'] ? array_map('trim', explode(',', $it['colors'])) : [],
            'quantity' => (float) $it['quantity'],
            'faulty_quantity' => (float) ($it['faulty_quantity'] ?? 0),
            'buying_price' => (float) $it['buying_price'],
            'package_buying_price' => $it['package_buying_price'] ?? null,
            'retail_price' => (float) $it['retail_price'],
            'wholesale_price' => (float) ($it['wholesale_price'] ?: $it['retail_price']),
            'description' => $it['notes'] ?? null,
            'offer_price' => $it['offer_price'] ?? '',
            'offer_starts_at' => $it['offer_starts_at'] ?? '',
            'offer_ends_at' => $it['offer_ends_at'] ?? '',
            'image_path' => $it['image_path'] ?? '',
            'status' => 'active',
        ]);
        if (!$res['ok']) {
            throw new \RuntimeException('Could not create inventory product: ' . json_encode($res['errors']));
        }
        $productId = (int) $res['id'];
        $this->applyQuantityDiscountsFromNotes($productId, (string) ($it['notes'] ?? ''));
        return $productId;
    }

    /** Reuse the Store→Inventory product matching logic for direct purchase intake. */
    public function upsertDirectInventory(ProductModel $productModel, array $item): int
    {
        return $this->transferOneToInventory($productModel, $item);
    }

    /** Apply [QDISC]{...} quantity-discount tiers stored on store product notes. */
    private function applyQuantityDiscountsFromNotes(int $productId, string $notes): void
    {
        if ($productId <= 0 || $notes === '' || strpos($notes, '[QDISC]') === false) {
            return;
        }
        if (!preg_match('/\[QDISC\](\{.*\})\s*$/s', $notes, $m)) {
            return;
        }
        $payload = json_decode($m[1], true);
        $tiers = is_array($payload['quantity_discounts'] ?? null) ? $payload['quantity_discounts'] : [];
        if (!$tiers) {
            return;
        }
        (new PriceTierModel($this->db))->replaceForProduct($productId, $tiers);
    }

    private function restockExistingInventoryProduct(array $existing, array $it): void
    {
        $productId = (int) $existing['id'];
        $tid = \TenantContext::tenantId();
        $sets = [
            'quantity = quantity + ?',
            'faulty_quantity = faulty_quantity + ?',
        ];
        $params = [
            (float) $it['quantity'],
            max(0, (float) ($it['faulty_quantity'] ?? 0)),
        ];

        $fields = [
            'buying_price' => ['buying_price', 'float'],
            'package_buying_price' => ['package_buying_price', 'float_or_null'],
            'retail_price' => ['retail_price', 'float'],
            'wholesale_price' => ['wholesale_price', 'float'],
            'unit' => ['unit', 'string'],
            'units_per_package' => ['units_per_pack', 'float_positive'],
            'package_unit' => ['pack_unit', 'string'],
            'package_price' => ['pack_price', 'float_or_null'],
            'retail_pack_price' => ['retail_pack_price', 'float_or_null'],
        ];

        foreach ($fields as $itKey => [$dbKey, $type]) {
            $val = $it[$itKey] ?? '';
            if ($type === 'float' && (float) $val > 0) {
                $sets[] = "$dbKey = ?";
                $params[] = (float) $val;
                if ($dbKey === 'retail_price') {
                    $sets[] = 'selling_price = ?';
                    $params[] = (float) $val;
                }
            } elseif ($type === 'float_or_null' && $val !== '' && (float) $val > 0) {
                $sets[] = "$dbKey = ?";
                $params[] = (float) $val;
            } elseif ($type === 'string' && $val !== '') {
                $sets[] = "$dbKey = ?";
                $params[] = (string) $val;
            } elseif ($type === 'float_positive' && (float) $val > 0) {
                $sets[] = "$dbKey = ?";
                $params[] = (float) $val;
            }
        }

        foreach (['category_id', 'brand_id', 'supplier_id'] as $column) {
            if ((int) ($it[$column] ?? 0) > 0) {
                $sets[] = $column . ' = ?';
                $params[] = (int) $it[$column];
            }
        }
        $colors = $it['colors'] ? array_values(array_filter(array_map('trim', explode(',', $it['colors'])))) : [];
        if ($colors) {
            $sets[] = 'colors = ?';
            $params[] = json_encode($colors);
        }
        if (($it['image_path'] ?? '') !== '') {
            $sets[] = 'image_path = ?';
            $params[] = $it['image_path'];
        }
        if (($it['offer_price'] ?? '') !== '') {
            $sets[] = 'offer_price = ?';
            $sets[] = 'offer_starts_at = ?';
            $sets[] = 'offer_ends_at = ?';
            $params[] = (float) $it['offer_price'];
            $params[] = $it['offer_starts_at'] ?: null;
            $params[] = $it['offer_ends_at'] ?: null;
        }
        $params[] = $productId;
        $params[] = $tid;
        $this->db->prepare('UPDATE products SET ' . implode(', ', $sets) . ' WHERE id = ? AND tenant_id = ?')->execute($params);
    }

    private function findExistingInventoryProduct(array $it): ?array
    {
        $tid = \TenantContext::tenantId();
        $name = trim((string) ($it['name'] ?? ''));
        if ($name === '') {
            return null;
        }
        $stmt = $this->db->prepare(
            "SELECT * FROM products
              WHERE tenant_id = ? AND status IN ('active','draft','archived') AND LOWER(name) = LOWER(?)
                AND COALESCE(category_id, 0) = ? AND COALESCE(brand_id, 0) = ?
              ORDER BY id ASC LIMIT 1"
        );
        $stmt->execute([
            $tid,
            $name,
            (int) ($it['category_id'] ?? 0),
            (int) ($it['brand_id'] ?? 0),
        ]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private function dateOrNull($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '' || strtotime($value) === false) {
            return null;
        }
        return date('Y-m-d H:i:s', strtotime($value));
    }

    private function ensureSchema(): void
    {
        if ($this->db->getAttribute(\PDO::ATTR_DRIVER_NAME) === 'sqlite') { return; }
        $this->ensureTable(
            'store_products',
            "CREATE TABLE IF NOT EXISTS store_products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id INT NOT NULL,
                product_id INT NULL,
                transferred_invoice_id INT NULL,
                name VARCHAR(160) NOT NULL,
                category_id INT NULL,
                brand_id INT NULL,
                supplier_id INT NULL,
                barcode VARCHAR(64) NULL,
                unit VARCHAR(20) NOT NULL DEFAULT 'piece',
                package_unit VARCHAR(20) NULL,
                package_quantity DECIMAL(12,2) NULL,
                units_per_package DECIMAL(12,2) NULL,
                package_price DECIMAL(12,2) NULL,
                retail_pack_price DECIMAL(12,2) NULL,
                colors VARCHAR(255) NULL,
                quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                faulty_quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                buying_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                package_buying_price DECIMAL(12,2) NULL,
                retail_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                wholesale_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                offer_price DECIMAL(12,2) NULL,
                offer_starts_at DATETIME NULL,
                offer_ends_at DATETIME NULL,
                image_path VARCHAR(255) NULL,
                notes TEXT NULL,
                status ENUM('stored','transferred') NOT NULL DEFAULT 'stored',
                created_by INT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                transferred_at DATETIME NULL,
                KEY idx_store_products_tenant_status (tenant_id, status),
                KEY idx_store_products_invoice (tenant_id, transferred_invoice_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $this->ensureColumn('store_products', 'supplier_id', "ALTER TABLE `store_products` ADD COLUMN `supplier_id` INT NULL AFTER `brand_id`");
        $this->ensureColumn('store_products', 'package_unit', "ALTER TABLE `store_products` ADD COLUMN `package_unit` VARCHAR(20) NULL AFTER `unit`");
        $this->ensureColumn('store_products', 'package_quantity', "ALTER TABLE `store_products` ADD COLUMN `package_quantity` DECIMAL(12,2) NULL AFTER `package_unit`");
        $this->ensureColumn('store_products', 'units_per_package', "ALTER TABLE `store_products` ADD COLUMN `units_per_package` DECIMAL(12,2) NULL AFTER `package_quantity`");
        $this->ensureColumn('store_products', 'package_price', "ALTER TABLE `store_products` ADD COLUMN `package_price` DECIMAL(12,2) NULL AFTER `units_per_package`");
        $this->ensureColumn('store_products', 'retail_pack_price', "ALTER TABLE `store_products` ADD COLUMN `retail_pack_price` DECIMAL(12,2) NULL AFTER `package_price`");
        $this->ensureColumn('products', 'retail_pack_price', "ALTER TABLE `products` ADD COLUMN `retail_pack_price` DECIMAL(12,2) NULL AFTER `pack_price`");
        $this->ensureColumn('store_products', 'package_buying_price', "ALTER TABLE `store_products` ADD COLUMN `package_buying_price` DECIMAL(12,2) NULL AFTER `buying_price`");
        $this->ensureColumn('store_products', 'offer_price', "ALTER TABLE `store_products` ADD COLUMN `offer_price` DECIMAL(12,2) NULL AFTER `wholesale_price`");
        $this->ensureColumn('store_products', 'offer_starts_at', "ALTER TABLE `store_products` ADD COLUMN `offer_starts_at` DATETIME NULL AFTER `offer_price`");
        $this->ensureColumn('store_products', 'offer_ends_at', "ALTER TABLE `store_products` ADD COLUMN `offer_ends_at` DATETIME NULL AFTER `offer_starts_at`");
        $this->ensureColumn('store_products', 'image_path', "ALTER TABLE `store_products` ADD COLUMN `image_path` VARCHAR(255) NULL AFTER `offer_ends_at`");
        // Quantity-discount JSON ([QDISC]...) needs room beyond VARCHAR(255).
        // Only ALTER when needed — MySQL DDL implicitly commits open transactions.
        try {
            $type = $this->db->query(
                "SELECT DATA_TYPE FROM information_schema.COLUMNS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'store_products' AND COLUMN_NAME = 'notes'
                  LIMIT 1"
            )->fetchColumn();
            if ($type && strtolower((string) $type) !== 'text' && strtolower((string) $type) !== 'mediumtext' && strtolower((string) $type) !== 'longtext') {
                $this->db->exec('ALTER TABLE store_products MODIFY COLUMN notes TEXT NULL');
            }
        } catch (\PDOException $ignored) {
        }
        $this->ensureTable(
            'store_invoices',
            "CREATE TABLE IF NOT EXISTS store_invoices (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id INT NOT NULL,
                invoice_number VARCHAR(32) NOT NULL,
                invoice_to VARCHAR(160) NULL,
                total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                notes VARCHAR(255) NULL,
                created_by INT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_store_invoice (tenant_id, invoice_number),
                KEY idx_store_invoice_tenant (tenant_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $this->ensureTable(
            'store_invoice_items',
            "CREATE TABLE IF NOT EXISTS store_invoice_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id INT NOT NULL,
                invoice_id INT NOT NULL,
                store_product_id INT NOT NULL,
                product_id INT NULL,
                product_name VARCHAR(160) NOT NULL,
                quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                unit VARCHAR(20) NULL,
                package_unit VARCHAR(20) NULL,
                package_quantity DECIMAL(12,2) NULL,
                units_per_package DECIMAL(12,2) NULL,
                package_price DECIMAL(12,2) NULL,
                unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                KEY idx_store_invoice_items_invoice (tenant_id, invoice_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $this->ensureColumn('store_invoice_items', 'package_unit', "ALTER TABLE `store_invoice_items` ADD COLUMN `package_unit` VARCHAR(20) NULL AFTER `unit`");
        $this->ensureColumn('store_invoice_items', 'package_quantity', "ALTER TABLE `store_invoice_items` ADD COLUMN `package_quantity` DECIMAL(12,2) NULL AFTER `package_unit`");
        $this->ensureColumn('store_invoice_items', 'units_per_package', "ALTER TABLE `store_invoice_items` ADD COLUMN `units_per_package` DECIMAL(12,2) NULL AFTER `package_quantity`");
        $this->ensureColumn('store_invoice_items', 'package_price', "ALTER TABLE `store_invoice_items` ADD COLUMN `package_price` DECIMAL(12,2) NULL AFTER `units_per_package`");
        $this->ensureColumn('store_invoices', 'invoice_type', "ALTER TABLE `store_invoices` ADD COLUMN `invoice_type` ENUM('transfer','return') NOT NULL DEFAULT 'transfer' AFTER `invoice_number`");
        $this->ensureColumn('store_invoices', 'source', "ALTER TABLE `store_invoices` ADD COLUMN `source` VARCHAR(64) NULL DEFAULT 'Store' AFTER `invoice_type`");
        $this->ensureColumn('store_invoices', 'destination', "ALTER TABLE `store_invoices` ADD COLUMN `destination` VARCHAR(64) NULL DEFAULT 'Shop Inventory' AFTER `source`");
        $this->ensureColumn('store_invoices', 'profit_impact', "ALTER TABLE `store_invoices` ADD COLUMN `profit_impact` DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `total`");
        $this->ensureColumn('store_invoice_items', 'profit_impact', "ALTER TABLE `store_invoice_items` ADD COLUMN `profit_impact` DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER `line_total`");
    }

    private function ensureTable(string $table, string $sql): void
    {
        try {
            $this->db->query("SELECT 1 FROM `{$table}` LIMIT 1");
        } catch (\PDOException $e) {
            try {
                $this->db->exec($sql);
            } catch (\PDOException $ignored) {
            }
        }
    }

    private function ensureColumn(string $table, string $column, string $sql): void
    {
        try {
            $this->db->query("SELECT `{$column}` FROM `{$table}` LIMIT 1");
        } catch (\PDOException $e) {
            try {
                $this->db->exec($sql);
            } catch (\PDOException $ignored) {
            }
        }
    }

    /** Adds product_summary to each store invoice row. */
    private function withProductSummary(array $rows): array
    {
        // "Sugar (2 kg), Rice (1.5 bag)" — built here, not in SQL, because
        // MySQL and SQLite disagree on RTRIM/GROUP_CONCAT syntax.
        $ids = array_map(static fn($r) => (int) $r['id'], $rows);
        $summary = [];
        if ($ids) {
            $items = $this->db->prepare(
                'SELECT invoice_id, product_name, quantity, unit FROM store_invoice_items
                  WHERE invoice_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id'
            );
            $items->execute($ids);
            foreach ($items->fetchAll() as $it) {
                $qty = rtrim(rtrim(number_format((float) $it['quantity'], 2, '.', ''), '0'), '.');
                $summary[(int) $it['invoice_id']][] = $it['product_name'] . ' (' . trim($qty . ' ' . ($it['unit'] ?? '')) . ')';
            }
        }
        foreach ($rows as &$r) {
            $r['product_summary'] = implode(', ', $summary[(int) $r['id']] ?? []);
        }
        unset($r);
        return $rows;
    }
}
