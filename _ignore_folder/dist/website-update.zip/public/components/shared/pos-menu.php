<?php
// Shared grouped POS navigation. Included inside the owner/staff <nav>.
$menuUri = $_SERVER['REQUEST_URI'] ?? '';
$menuOwner = TenantContext::role() === 'tenant_owner';
$menuOn = static fn(string $needle): string => strpos($menuUri, $needle) !== false ? 'active' : '';
$menuGroupOpen = static function (array $needles) use ($menuUri): bool {
    foreach ($needles as $needle) {
        if (strpos($menuUri, $needle) !== false) {
            return true;
        }
    }
    return false;
};
$menuRoute = static function (string $owner, string $staff = '') use ($menuOwner): string {
    return public_url($menuOwner || $staff === '' ? $owner : $staff);
};
$moduleOn = static fn(string $module): bool => Modules::enabled($module, $__tenant ?? null);

$posOpen = $menuGroupOpen(['/shop', '/orders', '/sales', '/invoices', '/returns', '/customers', '/reports', '/data', '/documents', '/services']);
$inventoryOpen = $menuGroupOpen(['/inventory', '/store', '/purchases', '/suppliers', '/stationery', '/stock', '/publishers', '/categories']);
$financeOpen = $menuGroupOpen(['/finances', '/expenses', '/salary', '/payroll', '/commissions', '/taxes']);
$settingsOpen = $menuGroupOpen(['/admins', '/staff', '/settings', '/updates', '/setup', '/backup', '/clean_migrations']);
$menuUpcoming = [];
if ($moduleOn('services')) {
    try {
        $menuUpcoming = (new Models\BusinessServiceModel(Database::pdo()))->upcomingForUser((int) TenantContext::userId(), 60);
    } catch (\Throwable $ignored) {
    }
}
?>
<?php if ($menuUpcoming): $nextAppointment = $menuUpcoming[0]; ?>
<a class="t-link" href="<?php echo public_url('super/services/appointments.php?status=booked'); ?>" style="background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;">
  <i class="fas fa-bell" style="color:#ea580c;"></i>
  <span>Appointment soon<small class="d-block"><?php echo htmlspecialchars(date('g:i a', strtotime($nextAppointment['scheduled_at'])) . ' · ' . $nextAppointment['customer_name']); ?></small></span>
</a>
<?php endif; ?>
<a class="t-link <?php echo $menuOn('/dashboard'); ?>" href="<?php echo $menuRoute('super/dashboard/', 'staff/dashboard/'); ?>">
  <i class="fas fa-house"></i><span>Home</span>
</a>
<?php if ($menuOwner && !Desktop::enabled()): ?>
<a class="t-link <?php echo $menuOn('/download'); ?>" href="<?php echo public_url('download/'); ?>">
  <i class="fab fa-windows"></i><span>Offline Windows app</span>
</a>
<?php endif; ?>

<div class="t-group <?php echo $posOpen ? 'open' : ''; ?>" data-nav-group>
  <button type="button" class="t-link t-group-toggle <?php echo $posOpen ? 'active' : ''; ?>" aria-expanded="<?php echo $posOpen ? 'true' : 'false'; ?>">
    <i class="fas fa-cash-register"></i><span>POS</span><i class="fas fa-chevron-down t-group-caret"></i>
  </button>
  <div class="t-subnav">
    <?php if ($menuOwner || TenantContext::can(Capabilities::SALES_RECORD)): ?>
      <a class="t-sublink <?php echo $menuOn('/shop'); ?>" href="<?php echo $menuRoute('super/shop/', 'staff/dashboard/'); ?>">Shop</a>
      <?php if ($moduleOn('credit_sales')): ?><a class="t-sublink t-subsub <?php echo $menuOn('/orders/held'); ?>" href="<?php echo $menuRoute('super/orders/held.php', 'staff/orders/held.php'); ?>">Hold sales</a><?php endif; ?>
    <?php endif; ?>
    <?php if ($menuOwner || TenantContext::can(Capabilities::SALES_VIEW)): ?>
      <a class="t-sublink <?php echo $menuOn('/sales'); ?>" href="<?php echo $menuRoute('super/sales/', 'staff/sales/'); ?>">Sales</a>
    <?php endif; ?>
    <a class="t-sublink <?php echo $menuOn('/offline/history'); ?>" href="<?php echo public_url('offline/history.php'); ?>">Sales history (works offline)</a>
    <?php if ($menuOwner): ?>
      <?php if ($moduleOn('credit_sales')): ?><a class="t-sublink <?php echo $menuOn('/invoices'); ?>" href="<?php echo public_url('super/invoices/'); ?>">Invoices</a><?php endif; ?>
    <?php endif; ?>
    <?php if ($menuOwner || TenantContext::can(Capabilities::SALES_RECORD)): ?>
      <?php if ($moduleOn('credit_sales')): ?><a class="t-sublink <?php echo $menuOn('/orders'); ?>" href="<?php echo $menuRoute('super/orders/', 'staff/orders/'); ?>">Credit Sales</a><?php endif; ?>
      <?php if ($moduleOn('returns')): ?><a class="t-sublink <?php echo $menuOn('/returns'); ?>" href="<?php echo $menuRoute('super/returns/', 'staff/returns/'); ?>">Returns</a><?php endif; ?>
    <?php endif; ?>
    <?php if ($moduleOn('customers') && ($menuOwner || TenantContext::can(Capabilities::CUSTOMERS_MANAGE))): ?>
      <a class="t-sublink <?php echo $menuOn('/customers'); ?>" href="<?php echo public_url('super/customers/'); ?>">Customers / Loyalty</a>
    <?php endif; ?>
    <?php if ($moduleOn('reports') && ($menuOwner || TenantContext::can(Capabilities::REPORTS_VIEW))): ?>
      <a class="t-sublink <?php echo $menuOn('/reports/') && !$menuOn('/reports/inventory') ? 'active' : ''; ?>" href="<?php echo public_url('super/reports/'); ?>">Reports</a>
      <a class="t-sublink <?php echo $menuOn('/reports/inventory'); ?>" href="<?php echo public_url('super/reports/inventory.php'); ?>">Inventory &amp; finance report</a>
      <a class="t-sublink <?php echo $menuOn('/tracker/'); ?>" href="<?php echo public_url('super/tracker/'); ?>">Product Tracker</a>
      <a class="t-sublink <?php echo $menuOn('/data'); ?>" href="<?php echo public_url('super/data/'); ?>">Data export</a>
    <?php endif; ?>
    <?php if ($moduleOn('documents')): ?><a class="t-sublink <?php echo $menuOn('/documents'); ?>" href="<?php echo $menuRoute('super/documents/', 'staff/documents/'); ?>">Documents</a><?php endif; ?>

    <?php if ($moduleOn('services')): ?>
    <div class="t-subsection"><i class="fas fa-concierge-bell me-1"></i>Services</div>
    <a class="t-sublink t-subsub <?php echo $menuOn('/services/sell'); ?>" href="<?php echo public_url('super/services/sell.php'); ?>">Sell services</a>
    <a class="t-sublink t-subsub <?php echo $menuOn('/services/appointments'); ?>" href="<?php echo public_url('super/services/appointments.php'); ?>">Appointments</a>
    <?php if ($menuOwner): ?>
      <a class="t-sublink t-subsub <?php echo $menuOn('/services/new'); ?>" href="<?php echo public_url('super/services/new.php'); ?>">Create services</a>
    <?php endif; ?>
    <a class="t-sublink t-subsub <?php echo strpos($menuUri, '/services/') !== false && strpos($menuUri, '/services/sell') === false && strpos($menuUri, '/services/appointments') === false && strpos($menuUri, '/services/new') === false ? 'active' : ''; ?>" href="<?php echo public_url('super/services/'); ?>">View services</a>
    <?php endif; ?>
  </div>
</div>

<?php if ($moduleOn('inventory') && ($menuOwner || TenantContext::can(Capabilities::INVENTORY_VIEW) || TenantContext::can(Capabilities::INVENTORY_EDIT) || TenantContext::can(Capabilities::STOCK_ENTER))): ?>
<div class="t-group <?php echo $inventoryOpen ? 'open' : ''; ?>" data-nav-group>
  <button type="button" class="t-link t-group-toggle <?php echo $inventoryOpen ? 'active' : ''; ?>" aria-expanded="<?php echo $inventoryOpen ? 'true' : 'false'; ?>">
    <i class="fas fa-warehouse"></i><span>Inventory</span><i class="fas fa-chevron-down t-group-caret"></i>
  </button>
  <div class="t-subnav">
    <a class="t-sublink <?php echo $menuOn('/inventory'); ?>" href="<?php echo public_url('super/inventory/'); ?>">Shop Inventory</a>
    <a class="t-sublink <?php echo $menuOn('/store'); ?>" href="<?php echo public_url('super/store/'); ?>">Store Warehouse</a>
    <div class="t-subsection"><i class="fas fa-cart-shopping me-1"></i>Purchases</div>
    <a class="t-sublink t-subsub <?php echo $menuOn('/purchases/new'); ?>" href="<?php echo public_url('super/purchases/new.php'); ?>">Record purchase</a>
    <a class="t-sublink t-subsub <?php echo strpos($menuUri, '/purchases/') !== false && strpos($menuUri, '/purchases/new') === false && strpos($menuUri, '/purchases/track') === false && strpos($menuUri, '/purchases/transfer') === false ? 'active' : ''; ?>" href="<?php echo public_url('super/purchases/'); ?>">View purchases</a>
    <a class="t-sublink t-subsub <?php echo $menuOn('/purchases/track'); ?>" href="<?php echo public_url('super/purchases/track.php'); ?>">Track purchases</a>
    <a class="t-sublink t-subsub <?php echo $menuOn('/purchases/transfer'); ?>" href="<?php echo public_url('super/purchases/transfer.php'); ?>">Transfer purchases</a>
    <a class="t-sublink <?php echo $menuOn('/suppliers'); ?>" href="<?php echo public_url('super/suppliers/'); ?>">Suppliers</a>
    <a class="t-sublink <?php echo $menuOn('/stationery'); ?>" href="<?php echo public_url('super/stationery/new.php'); ?>">Record Stock</a>
    <a class="t-sublink <?php echo $menuOn('/stock'); ?>" href="<?php echo public_url('super/stock/new.php'); ?>">Bulk Stock</a>
    <a class="t-sublink <?php echo $menuOn('/inventory/low-stock'); ?>" href="<?php echo public_url('super/inventory/low-stock.php'); ?>">Low Stock Alerts</a>
    <a class="t-sublink <?php echo $menuOn('/publishers'); ?>" href="<?php echo public_url('super/publishers/'); ?>">Brands</a>
    <a class="t-sublink <?php echo $menuOn('/categories'); ?>" href="<?php echo public_url('super/categories/'); ?>">Categories</a>
  </div>
</div>
<?php endif; ?>

<?php if ($menuOwner && ($moduleOn('finances') || $moduleOn('payroll') || $moduleOn('commissions'))): ?>
<div class="t-group <?php echo $financeOpen ? 'open' : ''; ?>" data-nav-group>
  <button type="button" class="t-link t-group-toggle <?php echo $financeOpen ? 'active' : ''; ?>" aria-expanded="<?php echo $financeOpen ? 'true' : 'false'; ?>">
    <i class="fas fa-coins"></i><span>Finances</span><i class="fas fa-chevron-down t-group-caret"></i>
  </button>
  <div class="t-subnav">
    <?php if ($moduleOn('finances')): ?>
    <a class="t-sublink <?php echo $menuOn('/finances'); ?>" href="<?php echo public_url('super/finances/'); ?>">Finances</a>
    <a class="t-sublink <?php echo $menuOn('/expenses'); ?>" href="<?php echo public_url('super/expenses/'); ?>">Expenses</a>
    <a class="t-sublink <?php echo $menuOn('/taxes'); ?>" href="<?php echo public_url('super/taxes/'); ?>">Taxes</a>
    <?php endif; ?>
    <?php if ($moduleOn('payroll')): ?><a class="t-sublink <?php echo $menuOn('/payroll'); ?>" href="<?php echo public_url('super/payroll/'); ?>">Salary & Payroll</a><?php endif; ?>
    <?php if ($moduleOn('commissions')): ?><a class="t-sublink <?php echo $menuOn('/commissions'); ?>" href="<?php echo public_url('super/commissions/'); ?>">Commission</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if ($menuOwner): ?>
<div class="t-group <?php echo $settingsOpen ? 'open' : ''; ?>" data-nav-group>
  <button type="button" class="t-link t-group-toggle <?php echo $settingsOpen ? 'active' : ''; ?>" aria-expanded="<?php echo $settingsOpen ? 'true' : 'false'; ?>">
    <i class="fas fa-gears"></i><span>Settings</span><i class="fas fa-chevron-down t-group-caret"></i>
  </button>
  <div class="t-subnav">
    <?php if ((int) ($__tenant['owner_user_id'] ?? 0) === (int) TenantContext::userId()): ?>
      <a class="t-sublink <?php echo $menuOn('/admins'); ?>" href="<?php echo public_url('super/admins/'); ?>">Admins</a>
    <?php endif; ?>
    <?php if ($moduleOn('staff')): ?>
      <a class="t-sublink <?php echo $menuOn('/staff') && !$menuOn('/permissions'); ?>" href="<?php echo public_url('super/staff/'); ?>">Staff</a>
      <a class="t-sublink <?php echo $menuOn('/permissions'); ?>" href="<?php echo public_url('super/staff/permissions.php'); ?>">Permissions</a>
    <?php endif; ?>
    <a class="t-sublink <?php echo $menuOn('/clean_migrations'); ?>" href="<?php echo public_url('clean_migrations.php'); ?>">Clean records</a>
    <a class="t-sublink <?php echo $menuOn('/settings'); ?>" href="<?php echo public_url('super/settings/'); ?>">Settings toggles</a>
    <?php if ((int) ($__tenant['owner_user_id'] ?? 0) === (int) TenantContext::userId()): ?>
      <a class="t-sublink <?php echo $menuOn('/updates'); ?>" href="<?php echo public_url('super/updates/'); ?>">System updates</a>
      <a class="t-sublink <?php echo $menuOn('/setup'); ?>" href="<?php echo public_url('setup/'); ?>">Owner account</a>
      <?php if (Desktop::enabled()): ?><a class="t-sublink <?php echo $menuOn('/backup'); ?>" href="<?php echo public_url('super/backup/'); ?>">Backups</a><?php endif; ?>
    <?php endif; ?>
    <?php if ((int) ($__tenant['owner_user_id'] ?? 0) === (int) TenantContext::userId() && !Modules::supportLocked()): ?>
      <a class="t-sublink <?php echo $menuOn('/support'); ?>" href="<?php echo public_url('support/'); ?>">Developer support</a>
    <?php endif; ?>
  </div>
</div>
<?php else: ?>
<a class="t-link <?php echo $menuOn('/change-pin'); ?>" href="<?php echo public_url('staff/change-pin.php'); ?>">
  <i class="fas fa-key"></i><span>Change PIN</span>
</a>
<?php endif; ?>
