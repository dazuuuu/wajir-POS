<?php
// public/components/topbar_actions.php — right side of the page top bar:
// date, who's logged in, and a Logout button that's always visible (the
// sidebar's own logout sits in the bottom-left corner, which the floating
// offline buttons used to cover, and the sidebar is hidden on phones).
$__who = (string) ($_SESSION['username'] ?? '');
?>
<div class="t-top-actions">
  <span class="text-muted small d-none d-lg-inline"><?php echo date('l, j M Y'); ?></span>
  <?php if ($__who !== ''): ?><span class="t-top-user d-none d-sm-inline"><i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($__who); ?></span><?php endif; ?>
  <a class="btn btn-sm btn-outline-danger t-top-logout" href="<?php echo public_url('auth/logout.php'); ?>" title="Logout" aria-label="Logout">
    <i class="fas fa-arrow-right-from-bracket"></i><span class="d-none d-sm-inline ms-1">Logout</span>
  </a>
</div>
<style>
.t-top-actions { display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
.t-top-user { font-size: .85rem; font-weight: 600; color: #475569; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.t-topbar h1 { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
<script>
(function () {
  // Don't let someone log out without realising offline sales are still on
  // this device only (logging out can make the next sync wait for a re-login).
  var link = document.currentScript && document.currentScript.parentNode.querySelector('.t-top-logout');
  if (!link) return;
  link.addEventListener('click', function (e) {
    e.preventDefault();
    var go = function () { if (window.PosAuth) PosAuth.logout(); else location.href = link.href; };
    if (!window.OfflineOrders) return go();
    OfflineOrders.count().then(function (n) {
      if (n > 0 && !confirm(n + ' offline change(s) haven\'t synced yet. They stay safely on this device and sync after you log back in. Log out anyway?')) return;
      go();
    }, go);
  });
})();
</script>
